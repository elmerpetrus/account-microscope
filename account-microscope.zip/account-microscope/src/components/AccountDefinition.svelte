<script lang="ts">
  export let href: string;
</script>

<a target="_blank" rel="noreferrer" href={href} style="font-size:small; font-weight:normal; text-decoration: none;">🔡</a>
