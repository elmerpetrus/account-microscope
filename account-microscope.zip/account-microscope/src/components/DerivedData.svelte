<div>
  <h3>🧰 Derived</h3>
  <dl style="font-size: smaller">
  <slot />
  </dl>
</div>
