<div>
  <h3>🧑‍🔬 Laboratory</h3>
  <dl style="font-size: smaller">
  <slot />
  </dl>
</div>
