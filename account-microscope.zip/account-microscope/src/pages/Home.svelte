<h2>Supported Accounts</h2>
<ul>
  <li>Whirlpool / Whirlpool</li>
  <li>Whirlpool / WhirlpoolsConfig</li>
  <li>Whirlpool / WhirlpoolsConfigExtension</li>
  <li>Whirlpool / TokenBadge</li>
  <li>Whirlpool / FeeTier</li>
  <li>Whirlpool / Position</li>
  <li>Whirlpool / TickArray</li>
  <li>Whirlpool / PositionBundle</li>
  <li>Token / Mint</li>
  <li>Token / Account</li>
  <li>Token2022 / Mint</li>
  <li>Token2022 / Account</li>
  <li>TokenSwap / SwapState</li>
  <li>Aquafarm / GlobalFarm</li>
  <li>Aquafarm / UserFarm</li>
  <li>Generic</li>
</ul>


